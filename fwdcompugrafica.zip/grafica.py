# programa que dibuja un punto y lo mueve a la derecha y izquierda 
import pygame
import math

if __name__ == "__main__":

    ancho=640
    alto=480
    verde = [0,255,0]
    blanco = [255,255,233]
    negro = [0,0,0]
    con = 0
    pos = [100,100]
    vel_x = 0
    reloj= pygame.time.Clock()  
    pygame.init()  # inicializa el constructor de pygame

    pantalla = pygame.display.set_mode([ancho,alto])

    fin = False

    while not fin:
        for event in pygame.event.get(): # detecta los eventos en la ventana
            if event.type == pygame.QUIT:  # detecta la "x" de la ventana y cierra la ventana
                fin= True
            if event.type == pygame.KEYDOWN:  # si se oprime cualquier tecla
                if event.key== pygame.K_RIGHT: # si se oprime flecha derecha 
                    vel_x = 2  # aumente la velocidad a 2 -> la posición en x aumenta
                if event.key== pygame.K_LEFT: # flecha izquierda
                    vel_x = -2    # --> la posición en x disminuye
                if event.key== pygame.K_s: # detecta si se oprime la s
                    vel_x = 0  # el ciculo se detiene 

        pos[0] += vel_x 
        pantalla.fill(negro) #pinta la pantalla de negro, para que de el efecto de que el punto se esta moviendo
        pygame.draw.circle(pantalla,verde,pos,2) #dibuja un punto, dado que no se especifica el radio, este sera cero
        pygame.display.flip()  # actualiza
        reloj.tick(30) # controla el framerate(cuadros por segundo) --> si aumentan los ticks, seran mas frames x seg
        # el punto se movera más rapido
        con +=1  # ¿Cúal es el periodo del contador? -- depende del computador?

    
