import pygame
import math

def trans(centro,pos):
    xpri= pos[0] + centro[0]
    ypri = centro[1]- pos[1]

    return [xpri,ypri]

def transinv(centro,pospan):
    x= pospan[0] - centro[0]
    y = centro[1]- pospan[1]

    return [x,y]

def rotar(punto,angulo):

    x = int(punto[0]*math.cos(angulo) - punto[1]*math.sin(angulo))
    y= int(punto[0]*math.sin(angulo) + punto[1]*math.cos(angulo))

    return [x,y]

if __name__ == "__main__":

    ancho=640
    alto=480
    verde = [0,255,0]
    blanco = [255,255,233]
    negro = [0,0,0]
    txty = [300,200]
    pos =[100,100]
    pygame.init()
    con = 0
    linf= -txty[0]
    posrot =[]
    pantalla = pygame.display.set_mode([ancho,alto])

#    pygame.draw.circle(pantalla,verde,trans(txty,pos),2)
    pygame.draw.line(pantalla,blanco,[txty[0],0],[txty[0],700])
    pygame.draw.line(pantalla,blanco,[0,txty[1]],[800,txty[1]])
    pygame.display.flip()  # actualiza
    fin = False

    while not fin:
        for event in pygame.event.get(): # detecta los eventos en la ventana
            if event.type == pygame.QUIT:  # detecta la "x" de la ventana y cierra la ventana
                fin= True
            if event.type == pygame.MOUSEBUTTONDOWN:
                print "djak"
                angulo = math.pi/2
                pos2 = list(pygame.mouse.get_pos())
                pygame.draw.circle(pantalla,verde,pos2,2)
                #print transinv(txty,pos2)


            if event.type == pygame.KEYDOWN:

                if event.key== pygame.K_s:
                    print "222"
                    posrot = rotar(pos2,angulo)
                    pygame.draw.circle(pantalla,verde,posrot,2)
                    pygame.display.flip()

        pygame.display.flip()
