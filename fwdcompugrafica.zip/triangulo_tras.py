import pygame
import math
import libreria_compu

if __name__ == "__main__":

    ancho=640
    alto=480
    verde = [0,255,0]
    blanco = [255,255,233]

    pun1 = [300, 300] # punto derecho
    pun2 = [100, 300] # punto iz
    pun3 = [200, 200] # punto superior
    ptras =[100,0]
    con = 0
    pygame.init()
    pantalla = pygame.display.set_mode([ancho,alto])

    pygame.draw.polygon(pantalla,blanco,[pun1,pun2,pun3],3)
    pygame.display.flip()
     
    fin = False

    while not fin:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                fin= True
            if event.type == pygame.KEYDOWN:

                pun1 = libreria_compu.tras(pun1,ptras)
                pun2 = libreria_compu.tras(pun2,ptras)
                pun3 = libreria_compu.tras(pun3,ptras)
                #rotar triangulo
                pygame.draw.polygon(pantalla,blanco,[pun1,pun2,pun3],3) 
                pygame.display.flip()