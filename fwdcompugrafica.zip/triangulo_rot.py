import pygame
import math
import libreria_compu

if __name__ == "__main__":

    ancho=640
    alto=480
    verde = [0,255,0]
    blanco = [255,255,233]

    pun1 = [500, 300] # punto derecho
    pun2 = [300, 300] # punto iz
    pun3 = [400, 200] # punto superior
    con = 0
    pygame.init()
    pantalla = pygame.display.set_mode([ancho,alto])

    pygame.draw.polygon(pantalla,blanco,[pun1,pun2,pun3],3)
    pygame.display.flip()
     
    fin = False

    while not fin:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                fin= True
            if event.type == pygame.KEYDOWN:

                angulo = math.pi/10
                pun1 = libreria_compu.rotar(pun1,angulo)
                pun2 = libreria_compu.rotar(pun2,angulo)
                pun3 = libreria_compu.rotar(pun3,angulo)
                #rotar triangulo
                pygame.draw.polygon(pantalla,blanco,[pun1,pun2,pun3],3) 
                pygame.display.flip()