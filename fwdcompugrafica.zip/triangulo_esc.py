import pygame
import math
import libreria_compu

if __name__ == "__main__":

    ancho=640
    alto=480
    verde = [0,255,0]
    blanco = [255,255,233]

    pun1 = [300, 300] # punto derecho
    pun2 = [100, 300] # punto iz
    pun3 = [200, 200] # punto superior
    escalar =[2,2] # escalar en x y y
    con = 0
    pygame.init()
    pantalla = pygame.display.set_mode([ancho,alto])

    pygame.draw.polygon(pantalla,blanco,[pun1,pun2,pun3],3)
    pygame.display.flip()
     
    fin = False

    while not fin:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                fin= True
            if event.type == pygame.KEYDOWN:

                pun1 = libreria_compu.escalar(pun1,escalar)
                pun2 = libreria_compu.escalar(pun2,escalar)
                pun3 = libreria_compu.escalar(pun3,escalar)
                #rotar triangulo
                pygame.draw.polygon(pantalla,blanco,[pun1,pun2,pun3],3) 
                pygame.display.flip()

                 # escalar punto
                """
                    pygame.draw.line(pantalla,blanco,escalar([150,100],[2,2]),escalar([200,200],[2,2]) )
                    pygame.draw.line(pantalla,blanco,escalar([150,100],[2,2]),escalar([100,200],[2,2]) )
                    pygame.draw.line(pantalla,blanco,escalar([100,200],[2,2]),escalar([200,200],[2,2]) )
                    pygame.display.flip()  """