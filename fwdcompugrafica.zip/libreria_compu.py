import math

def tras(p,t):

    lis=[]
    x = p[0] + t[0]
    y = p[1] + t[1]
    lis.append(x)
    lis.append(y)

    return lis

def escalar(p,e):
    lis= []
    x = e[0]*p[0]
    y = e[1]*p[1]

    lis.append(x)
    lis.append(y)

    return lis

def rotar(punto,angulo):
    lis =[]
    x = punto[0]*math.cos(angulo) - punto[1]*math.sin(angulo)
    y=punto[0]*math.sin(angulo) + punto[1]*math.cos(angulo)

    return [x,y]