# Programa que captura don puntos insertados por el mouse y traza una linea
# que se desplazara a la derecha 

import pygame
import math

if __name__ == "__main__":

    ancho=640
    alto=480
    verde = [0,255,0]
    blanco = [255,255,233]
    negro = [0,0,0]
    con = 0

    vel_x = 0
    vel_y = 0

    reloj= pygame.time.Clock()
    pygame.init()

    pantalla = pygame.display.set_mode([ancho,alto])

    fin = False

    while not fin:

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                fin= True
            if event.type == pygame.MOUSEBUTTONDOWN:

                if con == 0:
                    pos = list(pygame.mouse.get_pos())
                    print (pos)

                if con == 1:
                    pos2 = list(pygame.mouse.get_pos())
                    print (pos2)

                con +=1

        if con >= 2:
            pos[0] += 1
            pos2[0] += 1
            pantalla.fill(negro) # con esto estoy pintando-"borrando" el punto anterior y pintando uno nuevo
            pygame.draw.line(pantalla, blanco, pos, pos2)
            pygame.display.flip()
            reloj.tick(30)
                #con +=1
