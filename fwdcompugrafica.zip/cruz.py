import pygame
import math

if __name__ == "__main__":

    ancho=640
    alto=480
    verde = [0,255,0]
    blanco = [255,255,233]
    negro = [0,0,0]
    con = 0
    pos = [100,170]
    pos2 = [200,170]

    posy = [150,50]
    posy2 = [150,200]
    vel_x = 0
    vel_y = 0

    reloj= pygame.time.Clock()
    pygame.init()

    pantalla = pygame.display.set_mode([ancho,alto])

    fin = False

    while not fin:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                fin= True
            if event.type == pygame.KEYDOWN:
                if event.key== pygame.K_RIGHT:
                    vel_x = 2
                    vel_y = 0 # se detiene el movimiento en y, para que la cruz no se vaya a mover en diagonal
                if event.key== pygame.K_LEFT:
                    vel_x = -2
                    vel_y = 0
                if event.key== pygame.K_UP:
                    vel_y = -2
                    vel_x =0
                if event.key== pygame.K_DOWN:
                    vel_y = 2
                    vel_x = 0
                if event.key== pygame.K_s:
                    vel_x = 0
                    vel_y = 0

        pos[0] += vel_x
        pos2[0] += vel_x
        pos[1] += vel_y
        pos2[1] += vel_y

        posy[0] += vel_x
        posy2[0] += vel_x
        posy[1] += vel_y
        posy2[1] += vel_y

        pantalla.fill(negro)
        pygame.draw.line(pantalla, verde, pos, pos2)
        pygame.draw.line(pantalla, verde, posy, posy2)
        pygame.display.flip()
        reloj.tick(30)
        con +=1

        """
        pygame.draw.line(pantalla, blanco, [100+con,100], [200+con,100])
        pygame.draw.line(pantalla, blanco, [150+con,50], [150+con,300])



            pygame.draw.line(pantalla, blanco, [100,100], [200,100])
            pygame.draw.line(pantalla, blanco, [150,100], [150,300])
            pygame.display.flip()
        """
